create user 'iotms'@'localhost' identified by 'iotms';

create database iotmsdb character set=utf8;

grant all privileges on iotmsdb.* to 'iotms'@'localhost';

-- DROP TABLE iotmsdb.eventhistory;

-- eventhistory
create table iotmsdb.eventhistory (
	eventdate DATETIME  primary key,
	eventcontent varchar(2048)
) engine=InnoDB character set = utf8;



-- DROP TABLE iotmsdb.messagehistory;

-- eventhistory
create table iotmsdb.messagehistory (
	messagedate DATETIME  primary key,
	messagecontent varchar(2048)
) engine=InnoDB character set = utf8;

-- DROP TABLE iotmsdb.setting;

-- setting
create table iotmsdb.setting (
	`security_settime` INT(11) NULL DEFAULT NULL,
	`lightoff_settime` INT(11) NULL DEFAULT NULL,
	`logging_duration` INT(11) NULL DEFAULT NULL,
	`malfunc_settime` INT(11) NULL DEFAULT NULL,
	`doorsensor_settime` INT(11) NULL DEFAULT NULL
) engine=InnoDB character set = utf8;

insert into iotmsdb.setting value (10,5,21600,10,4);


-- DROP TABLE iotmsdb.user_info;
-- DROP TABLE iotmsdb.user_authority;

-- user
create table iotmsdb.user_info (
	user_id varchar(50) primary key,
	user_passwd varchar(50),
	user_name varchar(50),
	user_mail varchar(50),
	user_twitter varchar(50)
) engine=InnoDB character set = utf8;

CREATE TABLE iotmsdb.user_authority (
	user_id varchar(50) NOT NULL,
	autohrity VARCHAR(50) NOT NULL,
	UNIQUE INDEX user_id_autohrity (user_id, autohrity),
	CONSTRAINT FK_user_authority_user_info FOREIGN KEY (user_id) REFERENCES user_info (user_id) ON UPDATE CASCADE ON DELETE CASCADE
) engine=InnoDB character set = utf8;

insert into iotmsdb.user_info value ("admin","admin","admin","admin@itoms.com","");

insert into iotmsdb.user_authority value ("admin","ADMIN");
insert into iotmsdb.user_authority value ("admin","USER");


-- DROP TABLE iotmsdb.thing_info;
-- DROP TABLE iotmsdb.node_info;

CREATE TABLE iotmsdb.node_info (
	`node_id` VARCHAR(50) NOT NULL,
	`node_name` VARCHAR(50) NULL DEFAULT NULL,
	`url` VARCHAR(50) NULL DEFAULT NULL,
	`port` VARCHAR(50) NULL DEFAULT NULL,
	`serialnumber` VARCHAR(50) NULL DEFAULT NULL,
	`json` VARCHAR(2048) NULL DEFAULT NULL,
	`registered` INT(4) NULL DEFAULT '0',
	PRIMARY KEY (`node_id`)
) engine=InnoDB character set = utf8;

CREATE TABLE iotmsdb.thing_info (
	`node_id` VARCHAR(50) NOT NULL,
	`thing_id` VARCHAR(50) NOT NULL,
	`thing_name` VARCHAR(50)  NULL DEFAULT NULL,
	`type` VARCHAR(50) NULL DEFAULT NULL,
	`stype` VARCHAR(50) NULL DEFAULT NULL,
	`vtype` VARCHAR(50) NULL DEFAULT NULL,
	`vmin` VARCHAR(50) NULL DEFAULT NULL,
	`vmax` VARCHAR(50) NULL DEFAULT NULL,
	`value` VARCHAR(50) NULL DEFAULT NULL,
	`json` VARCHAR(2048) NULL DEFAULT NULL,
	PRIMARY KEY (`node_id`, `thing_id`),
	CONSTRAINT `FK_thing_info_node_info` FOREIGN KEY (`node_id`) REFERENCES `node_info` (`node_id`) ON UPDATE CASCADE ON DELETE CASCADE
) engine=InnoDB character set = utf8;



-- DROP TABLE iotmsdb.ruleset_info;

-- ruleset
create table iotmsdb.ruleset_info (
	`ruleset_id` INT(11) NOT NULL AUTO_INCREMENT,
	`ruleset` VARCHAR(512) NULL DEFAULT '0',
	PRIMARY KEY (`ruleset_id`)
) engine=InnoDB character set = utf8;

insert into iotmsdb.ruleset_info(ruleset) value ("if *@0010==Setting#Alarm 											then 78:c4:e:1:7f:f9@0001=Close#Door, 78:c4:e:1:7f:f9@0006=Open#DoorSensorDelay, *@0011=Malfunction#MessageDelay, *@0010=UnSet#AlarmDelay");
insert into iotmsdb.ruleset_info(ruleset) value ("if *@0010==Setting#Alarm, 78:c4:e:1:7f:f9@0006==Close#DoorSensor	then *@0010=Set#Alarm");
insert into iotmsdb.ruleset_info(ruleset) value ("if *@0010==Set#Alarm 												then !78:c4:e:1:7f:f9@0001=Open#Door, 78:c4:e:1:7f:f9@0008=On#AlarmLamp");
insert into iotmsdb.ruleset_info(ruleset) value ("if *@0010==UnSet#Alarm 											then 78:c4:e:1:7f:f9@0008=Off#AlarmLamp");
insert into iotmsdb.ruleset_info(ruleset) value ("if 78:c4:e:1:7f:f9@0003==Away#Presence 							then *@0011=Confirm#Message, *@0010=Setting#AlarmDelay, 78:c4:e:1:7f:f9@0002=Off#LightDelay");
insert into iotmsdb.ruleset_info(ruleset) value ("if *@0010==Set#Alarm, 78:c4:e:1:7f:f9@0003==AtHome#Presence 		then *@0011=Emergency#Message");
insert into iotmsdb.ruleset_info(ruleset) value ("if *@0010==Set#Alarm, 78:c4:e:1:7f:f9@0006==Open#DoorSensor 		then *@0011=Emergency#Message");
insert into iotmsdb.ruleset_info(ruleset) value ("if 78:c4:e:1:7f:f9@0005==Over100#Humidity		then *@0011=Malfunction#Message");
insert into iotmsdb.ruleset_info(ruleset) value ("if 78:c4:e:1:7f:f9@0004==Over50#Temperature		then *@0011=Malfunction#Message");
insert into iotmsdb.ruleset_info(ruleset) value ("if 78:c4:e:1:7f:f9@0004==Under0#Temperature		then *@0011=Malfunction#Message");
insert into iotmsdb.ruleset_info(ruleset) value ("if 78:c4:e:2:5b:b3@0007==Mail#MailBox								then *@0011=POST#Message");

