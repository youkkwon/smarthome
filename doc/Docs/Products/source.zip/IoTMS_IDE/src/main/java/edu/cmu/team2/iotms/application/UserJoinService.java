package edu.cmu.team2.iotms.application;

import java.util.Arrays;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.UserDetailsManager;
import org.springframework.transaction.annotation.Transactional;

import edu.cmu.team2.iotms.domain.NewUser;
import edu.cmu.team2.iotms.domain.UserInfo;

public class UserJoinService {
	private UserDetailsManager userDetailsManager;
	private PasswordEncoder passwordEncoder;

	public UserJoinService() {
		passwordEncoder = NoOpPasswordEncoder.getInstance();
	}

	@Transactional
	public void join(UserInfo newUser) {
		String password = passwordEncoder.encode(newUser.getUserPasswd());
		UserDetails user = new User(newUser.getUserId(), password,
				Arrays.asList(new SimpleGrantedAuthority("USER")));
		try {
			userDetailsManager.createUser(user);
		} catch (DuplicateKeyException ex) {
			throw new DuplicateUsernameException(
					String.format("User ID [%s] is aleady exists", newUser.getUserId()), ex);
		}
	}

	public void setUserDetailsManager(UserDetailsManager userDetailsManager) {
		this.userDetailsManager = userDetailsManager;
	}

	public void setPasswordEncoder(PasswordEncoder passwordEncoder) {
		this.passwordEncoder = passwordEncoder;
	}
}
