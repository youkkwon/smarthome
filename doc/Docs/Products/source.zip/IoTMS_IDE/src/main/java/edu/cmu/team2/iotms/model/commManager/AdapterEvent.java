package edu.cmu.team2.iotms.model.commManager;

public class AdapterEvent extends CommEvent {

	public AdapterEvent(String t, String s, String m, Object l) {
		super(t, s, m, l);
		// TODO Auto-generated constructor stub
	}
	
	public AdapterEvent(String t, String s, String m) {
		super(t, s, m);
		// TODO Auto-generated constructor stub
	}

}
