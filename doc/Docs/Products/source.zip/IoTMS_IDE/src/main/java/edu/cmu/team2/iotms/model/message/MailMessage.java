package edu.cmu.team2.iotms.model.message;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import Database.LoggerDao;
import edu.cmu.team2.iotms.domain.UserInfo;

public class MailMessage extends IoTMSMessage {
	//private UserServiceImpl userService;
	private JdbcTemplate jdbcTemplate;
	
	private JavaMailSenderImpl mailSender;
	
	public MailMessage(DataSource datasource) {
		super();
		
		mailSender = new JavaMailSenderImpl();
		
		mailSender.setHost("smtp.gmail.com");
		mailSender.setPort(587);
		mailSender.setUsername("swarchitect.cmu@gmail.com");
		mailSender.setPassword("cmuteam@");
		Properties javaMailProperties = mailSender.getJavaMailProperties();
		javaMailProperties.setProperty("mail.smtp.auth", "true");
		javaMailProperties.setProperty("mail.smtp.starttls.enable", "true");    
		mailSender.setJavaMailProperties(javaMailProperties);
		
		jdbcTemplate = new JdbcTemplate(datasource);
	}
	
	private List<UserInfo> getUsers() {
		String sql = "SELECT user_id, user_name, user_mail, user_twitter, user_passwd FROM user_info";
		System.out.println("getUsers sql : "+sql);
		List<UserInfo> users = jdbcTemplate.query(sql, new RowMapper<UserInfo>() {
	        @Override
	        public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
	        	UserInfo aUser = new UserInfo();
	        	
	        	aUser.setUserId(rs.getString("user_id"));
	        	aUser.setUserName(rs.getString("user_name"));
	        	aUser.setUserMail(rs.getString("user_mail"));
	        	aUser.setUserTwitter(rs.getString("user_twitter"));
	        	aUser.setUserPasswd(rs.getString("user_passwd"));
	        	
	        	return aUser;
	        }
	    });
	 
	    return users;
	}

	private String[] getReceiver() {
		List<UserInfo> users = getUsers();
		ArrayList<String> recevier = new ArrayList<String>();
		for(UserInfo user:users) {
			String mail = user.getUserMail();
			if(mail != null && mail.compareTo("") != 0)
				recevier.add(mail);
		}
		
		String[] strArr = new String[recevier.size()];
		strArr = recevier.toArray(strArr);
		
		return strArr;
	}

	@Override
	protected void sendConfirmMessage(String desc) {
		String[] address = getReceiver();
		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setSubject("[IoTMS] This is a Emergency Message");
		message.setFrom("no-reply@iotms.com");
		message.setText(" Confirm : "+desc
				+ " Alarm Set http://"+getLocalIp()+":8080/iotms/rule/confirm?set=Setting \n"
				+ " Alarm Unset http://"+getLocalIp()+":8080/iotms/rule/confirm?set=UnSet");
		message.setTo(address);
		try {
			mailSender.send(message);
			LoggerDao.getInstance().addMessageHistory("Send emergency mail("+desc+") to "+address.toString());
		} catch(MailException e) {
			e.printStackTrace();
		}
	}
	
	private String getLocalIp() {
		String localIP="";
		try {
			localIP = InetAddress.getLocalHost().getHostAddress();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return localIP;
	}

	@Override
	protected void sendEmergencyMessage(String desc) {
		String[] address = getReceiver();
		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setSubject("[IoTMS] This is a Emergency Message");
		message.setFrom("no-reply@iotms.com");
		message.setText("Emergency "+desc);
		message.setTo(address);
		try {
			mailSender.send(message);
			LoggerDao.getInstance().addMessageHistory("Send emergency mail("+desc+") to "+address.toString());
		} catch(MailException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void sendMalFunctionMessage(String desc) {
		String[] address = getReceiver();
		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setSubject("[IoTMS] This is a MalFunction Message");
		message.setFrom("no-reply@iotms.com");
		message.setText("Emerge mulfunction on system. "+desc);
		message.setTo(address);
		try {
			mailSender.send(message);
			LoggerDao.getInstance().addMessageHistory("Send mulfunction mail("+desc+") to "+address.toString());
		} catch(MailException e) {
			e.printStackTrace();
		}
	}

	@Override
	protected void sendPostMessage(String desc) {
		String[] address = getReceiver();
		
		SimpleMailMessage message = new SimpleMailMessage();
		message.setSubject("[IoTMS] You've got a mail in mailbox");
		message.setFrom("hanbell@gmail.com");
		message.setText("Check your mailbox in your house. "+desc);
		message.setTo(address);
		try {
			mailSender.send(message);
			LoggerDao.getInstance().addMessageHistory("Send check mailbox mail("+desc+") to "+address.toString());
		} catch(MailException e) {
			e.printStackTrace();
		}
	}

}
