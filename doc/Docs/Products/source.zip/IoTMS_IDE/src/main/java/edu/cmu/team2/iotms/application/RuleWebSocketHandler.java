package edu.cmu.team2.iotms.application;

import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.google.common.eventbus.Subscribe;

import edu.cmu.team2.iotms.model.eventBus.IoTMSEventBus;

public class RuleWebSocketHandler extends TextWebSocketHandler {

	private Map<String, WebSocketSession> users;

	public RuleWebSocketHandler() {
		super();
		
		users = new ConcurrentHashMap<>();
		
		IoTMSEventBus.getInstance().register(this);
	}

	@Override
	public void afterConnectionEstablished(
			WebSocketSession session) throws Exception {
		log(session.getId() + " Connected");
		users.put(session.getId(), session);
	}

	@Override
	public void afterConnectionClosed(
			WebSocketSession session, CloseStatus status) throws Exception {
		log(session.getId() + " Closed");
		users.remove(session.getId());
	}

	@Override
	protected void handleTextMessage(
			WebSocketSession session, TextMessage message) throws Exception {
		log("Message from " + session.getId() + ": "+ message.getPayload());
		for (WebSocketSession s : users.values()) {
			s.sendMessage(message);
			log("Message to " + s.getId() + ": " + message.getPayload());
		}
	}

	@Override
	public void handleTransportError(
			WebSocketSession session, Throwable exception) throws Exception {
		log(session.getId() + " Exception emerge: " + exception.getMessage());
	}

	private void log(String logmsg) {
		System.out.println(new Date() + " : " + logmsg);
	}
	
	@Subscribe
	public void SubscribeEvent(JSONObject JSONMsg) {
		JSONArray targets = (JSONArray) JSONMsg.get("Targets");
		for (int i=0; i < targets.size(); i++) {
			if (targets.get(i).equals("UIControler")) {
				if(JSONMsg.get("Job").toString().compareTo("RuleSearch") == 0)
					processSearch(JSONMsg);
			}
		}
	}
	
	private void processSearch(JSONObject JSONMsg) {
		
		TextMessage message = new TextMessage(JSONMsg.toJSONString());
		
		for (WebSocketSession s : users.values()) {
			try {
				s.sendMessage(message);
			} catch (IOException e) {
				e.printStackTrace();
			}
			log("Send Rule message to" +s.getId() 	+ ": " + message.getPayload());
		}

	}

}
