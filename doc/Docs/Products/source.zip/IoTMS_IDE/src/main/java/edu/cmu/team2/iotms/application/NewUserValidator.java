package edu.cmu.team2.iotms.application;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import edu.cmu.team2.iotms.domain.NewUser;
import edu.cmu.team2.iotms.domain.UserInfo;

public class NewUserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return NewUser.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userId", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userPasswd", "required");
		UserInfo newUser = (UserInfo) target;
		if (!newUser.isPasswordAndConfirmSame())
			errors.rejectValue("confirm", "notSame");
	}

}
