package edu.cmu.team2.iotms.uicontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import edu.cmu.team2.iotms.application.DuplicateUsernameException;
import edu.cmu.team2.iotms.application.NewUserValidator;
import edu.cmu.team2.iotms.application.UserJoinService;
import edu.cmu.team2.iotms.application.UserServiceImpl;
import edu.cmu.team2.iotms.domain.NewUser;
import edu.cmu.team2.iotms.domain.UserInfo;

@Controller
@RequestMapping("/user/join")
public class JoinController {
	public static final String USER_JOIN_SUCCESS = "user/joinSuccess";
	public static final String USER_JOIN_FORM = "user/joinForm";

	private UserJoinService userJoinService;
	
	@Autowired
	private UserServiceImpl userService;

	@ModelAttribute("newUser")
	public UserInfo formBacking() {
		return new UserInfo();
	}

	@RequestMapping(method = RequestMethod.GET)
	public String form() {
		return USER_JOIN_FORM;
	}

	@RequestMapping(method = RequestMethod.POST)
	public String submit(@ModelAttribute("newUser") UserInfo newUser, Errors errors) {
		new NewUserValidator().validate(newUser, errors);
		if (errors.hasErrors())
			return USER_JOIN_FORM;
		try {
			//userJoinService.join(newUser);
			userService.createUser(newUser);
			return USER_JOIN_SUCCESS;
		} catch (DuplicateUsernameException ex) {
			errors.rejectValue("name", "duplicate");
			return USER_JOIN_FORM;
		}
	}

	public void setUserJoinService(UserJoinService userJoinService) {
		this.userJoinService = userJoinService;
	}

}
