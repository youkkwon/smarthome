package edu.cmu.team2.iotms.uicontroller;

public class AuthorityController {

}
